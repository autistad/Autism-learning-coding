import React from 'react';

const BlurredText2 = ({ text }) => {
  return (
    <>
      {text.split('').map((char, index) => (
        <span key={index} className="blurred-letter2">
          {char}
        </span>
      ))}
    </>
  );
}

export default BlurredText2