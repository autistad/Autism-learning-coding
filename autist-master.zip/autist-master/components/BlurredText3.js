import React from 'react';

const BlurredText3 = ({ text }) => {
  return (
    <>
      {text.split('').map((char, index) => (
        <span key={index} className="blurred-letter3">
          {char}
        </span>
      ))}
    </>
  );
}

export default BlurredText3