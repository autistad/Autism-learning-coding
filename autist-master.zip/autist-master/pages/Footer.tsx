import React from "react";
import BlurredText from "../components/BlurredText";
import BlurredText2 from "../components/BlurredText2";
import BlurredText3 from "../components/BlurredText3";
import Link from "next/link";

function Footer() {
  return (
    <div className="h-full">
      <div className="flex flex-col justify-center items-center mb-10">
        <div className="mb-10">
          <BlurredText text="Join Our Socials" />
        </div>
        <div className="mb-10 text-center max-[1015px]:w-[90%]">
          <BlurredText2 text="Be sure to join our community to keep up-to-date and find out how you can get involved." />
        </div>
        <div className="flex justify-center items-center">
          <Link
            href="https://twitter.com/autismcoinerc?t=fxue3w3STCYJbnW9E1xiAg&s=09"
            rel="noreferrer"
            target="_blank"
          >
            <img
              className="w-10 mr-10 hover:scale-110 ease-in-out duration-300"
              src="/twitter.png"
              alt=""
            />
          </Link>
          <Link
            href="https://t.me/AutismPortal"
            rel="noreferrer"
            target="_blank"
          >
            <img
              className="w-10 hover:scale-110 ease-in-out duration-300"
              src="/Telegram.webp"
              alt=""
            />
          </Link>
        </div>
      </div>

      <div className="flex justify-center items-center mb-32">
        <div className="flex flex-col justify-center items-center border-4 border-[#4977ca] mt-10 px-96 max-[1250px]:px-72 max-[1015px]:px-52 max-[835px]:px-40 max-[720px]:px-20 max-[560px]:px-10 max-[475px]:px-5">
          <div className="my-10">
            <BlurredText3 text="I'm a jeeter, I have $autism" />
          </div>

          <div className="flex justify-center items-center mb-10">
            <div className="flex flex-col items-center justify-center mr-10">
              <Link
                className="underline cursor-pointer"
                href="https://www.dextools.io/app/en/ether/pair-explorer/0xf25e1076c8abbe7c164b71edb0d7d02982055c12"
                rel="noreferrer"
                target="_blank"
              >
                <BlurredText2 text="Chart" />
              </Link>
            </div>

            <div className="flex flex-col items-center justify-center">
              <div>
                <Link
                  className="ml-2 underline cursor-pointer"
                  href="https://app.uniswap.org/#/swap"
                  rel="noreferrer"
                  target="_blank"
                >
                  <BlurredText2 text="Buy Now" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Footer;
