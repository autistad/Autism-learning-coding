import React from "react";
import Link from "next/link";
import BlurredText from "../components/BlurredText";
import BlurredText2 from "../components/BlurredText2";
import Navbar from "./BurgerNav";

function Header() {
  return (
    <div className="flex justify-around items-center py-2 fixed border-8 border-[#4774d0] w-screen bg-white z-50">
      <div>
        <BlurredText text="$Autism" />
      </div>
      <div className="flex justify-center items-center max-[715px]:hidden">
        <Link
          href="https://twitter.com/autismcoinerc?t=fxue3w3STCYJbnW9E1xiAg&s=09"
          rel="noreferrer"
          target="_blank"
        >
          <img
            className="w-10 mr-10 hover:scale-110 ease-in-out duration-300"
            src="/twitter.png"
            alt=""
          />
        </Link>
        <Link href="https://t.me/AutismPortal" rel="noreferrer" target="_blank">
          <img
            className="w-10 hover:scale-110 ease-in-out duration-300"
            src="/Telegram.webp"
            alt=""
          />
        </Link>
      </div>
      <div className="flex justify-center items-center max-[715px]:hidden">
        <Link
          className="mr-10 cursor-pointer underline"
          href="https://www.dextools.io/app/en/ether/pair-explorer/0xf25e1076c8abbe7c164b71edb0d7d02982055c12"
          rel="noreferrer"
          target="_blank"
        >
          <BlurredText2 text="Chart" />
        </Link>

        <Link
          className="cursor-pointer underline"
          href="https://app.uniswap.org/#/swap"
          rel="noreferrer"
          target="_blank"
        >
          <BlurredText2 text="Buy Now" />
        </Link>
      </div>

      <Navbar />
    </div>
  );
}

export default Header;
