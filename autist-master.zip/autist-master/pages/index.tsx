import Header from "./header";
import Middle from "./middle";
import Footer from "./Footer";

export default function Home() {
  return (
    <div>
      <Header />
      <div className="flex justify-center items-center pb-12 max-[750px]:ml-0">
        <img className="mt-16 max-[835px]:w-[680px] max-[735px]:w-[580px] max-[610px]:w-[480px] max-[515px]:w-[380px] max-[410px]:w-[350px] max-[835px]:mt-32" src="/austin.png" alt="" />
      </div>

      <Middle/>
      <Footer/>
    </div>
  );
}
