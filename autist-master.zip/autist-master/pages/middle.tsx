import React from "react";
import BlurredText from "../components/BlurredText";
import BlurredText2 from "../components/BlurredText2";
import BlurredText3 from "../components/BlurredText3";

function Middle() {
  return (
    <div className="h-full">
      <div className="flex justify-center items-center mt-5">
        <BlurredText text="TOKENOMICS" />
      </div>

      <div className="flex justify-center items-center mt-20 mb-48">
        <div className="border-4 rounded-xl border-[#4774d0]">
          <div className="grid grid-cols-3 gap-4 max-[685px]:grid-cols-0 max-[685px]:grid-cols-1">
            <div className="flex flex-col justify-start items-start pl-10 py-10">
              <div>
                <BlurredText2 text="Token" />
              </div>
              <div>
                <BlurredText3 text="$Autism" />
              </div>
            </div>

            <div className="flex flex-col justify-center items-center py-10 px-10 max-[835px]:px-8 max-[775px]:px-5">
              <div>
                <BlurredText2 text="Buy and Sell Tax" />
              </div>
              <div>
                <BlurredText3 text="2% TAXES" />
              </div>
            </div>

            <div className="flex flex-col justify-end items-end pr-10 py-10">
              <div>
                <BlurredText2 text="Initial Supply" />
              </div>
              <div>
                <BlurredText3 text="999 Billion" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 max-[685px]:grid-cols-1">
            <div className="flex flex-col justify-start items-start pl-10 py-10 max-[685px]:pl-0 max-[685px]:pr-10 max-[685px]:justify-end max-[685px]:items-end">
              <div>
                <BlurredText2 text="Ownership" />
              </div>
              <div>
                <BlurredText3 text="Renounced" />
              </div>
            </div>

            <div className="flex flex-col justify-end items-end pr-10 py-10">
              <div>
                <BlurredText2 text="Launch" />
              </div>
              <div>
                <BlurredText3 text="Fair Launch" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Middle;
